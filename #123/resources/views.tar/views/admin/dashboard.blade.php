@extends('admin.layouts.master')

@section('content')

    {{ trans('quickadmin::admin.dashboard-title') }}

@endsection