<script>
CKEDITOR.replace('my-editor', options);
</script>
</body>
</html>
